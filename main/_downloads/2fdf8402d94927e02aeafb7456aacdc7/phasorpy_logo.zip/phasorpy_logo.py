"""
PhasorPy logo
=============

Create the PhasorPy logo using the PhasorPy library.

"""

# %%
#

from matplotlib import pyplot

import phasorpy  # noqa

pyplot.imshow([[3, 2], [1, 0]])

...

"""
File input/output
=================

Read and write phasor-related data in various file formats.

The :py:mod:`phasorpy.io` module provides functions to read phasor
coordinates, TCSPC time-delay histograms, cross-correlation phase histograms,
hyperspectral image stacks, lifetime images, and relevant metadata from
various file formats used in bioimaging.
The module also includes functions to write phasor coordinates to OME-TIFF
and SimFCS Referenced files.

"""

# %%
# Import required modules, functions, and classes:

import math
import os
from tempfile import TemporaryDirectory

import numpy

from phasorpy.filter import phasor_filter_median, phasor_threshold
from phasorpy.lifetime import phasor_calibrate, phasor_to_apparent_lifetime
from phasorpy.phasor import phasor_from_signal, phasor_transform
from phasorpy.plot import (
    plot_histograms,
    plot_phasor,
    plot_phasor_image,
    plot_signal_image,
)

# %%
# Sample files
# ------------
#
# PhasorPy provides access to curated sample files in various formats
# that are shared publicly on Zenodo, Figshare, and GitHub repositories.
# The files can be accessed using the :py:func:`~phasorpy.datasets.fetch`
# function, which transparently downloads files and caches them locally.
# The function returns the path to the downloaded file:

from phasorpy.datasets import fetch  # isort: skip

filename = fetch('FLIM_testdata.lif')
print(filename)

# %%
# Consider contributing datasets to the `PhasorPy Community on Zenodo
# <https://zenodo.org/communities/phasorpy/>`_.

# %%
# Leica LIF and XLEF
# ------------------
#
# Leica image files (LIF and XLEF) are written by Leica LAS X software.
# They contain collections of multidimensional images and metadata from
# a variety of microscopy acquisition and analysis modes.
#
# PhasorPy supports reading hyperspectral images, phasor coordinates,
# and lifetime images from Leica image files via the
# `liffile <https://github.com/cgohlke/liffile/>`_ library.
#
# LIF FLIM
# ........
#
# Leica image files, acquired on a FALCON microscope and analyzed with LAS X
# software, contain calculated phasor coordinates, lifetime images, and
# relevant metadata. The :py:func:`~phasorpy.io.phasor_from_lif` and
# :py:func:`~phasorpy.io.lifetime_from_lif` functions are used to read that
# data from the `FLIM testdata dataset
# <https://dx.doi.org/10.6084/m9.figshare.22336594.v1>`_ :

from phasorpy.io import lifetime_from_lif, phasor_from_lif

filename = 'FLIM_testdata.lif'

mean, real, imag, attrs = phasor_from_lif(fetch(filename))

plot_phasor_image(mean, real, imag, title=filename)

# %%
# The returned mean intensity and uncalibrated phasor coordinates are
# NumPy arrays. ``attrs`` is a dictionary holding metadata, including the
# auto-reference phase (in degrees) and modulation for all image channels,
# as well as the fundamental frequency (in MHz):

frequency = attrs['frequency']
channel_0 = attrs['flim_phasor_channels'][0]
reference_phase = channel_0['AutomaticReferencePhase']
reference_modulation = channel_0['AutomaticReferenceAmplitude']
intensity_min = channel_0['IntensityThreshold'] / attrs['samples']

# %%
# These metadata are used to calibrate and threshold the phasor coordinates:

real, imag = phasor_transform(
    real, imag, -math.radians(reference_phase), 1 / reference_modulation
)

mean, real, imag = phasor_threshold(mean, real, imag, mean_min=intensity_min)

plot_phasor(
    real,
    imag,
    frequency=frequency,
    cmin=10,
    title=f'{filename} ({frequency} MHz)',
)

# %%
# Apparent single lifetimes are calculated from the calibrated phasor
# coordinates and compared to the "Fast FLIM" lifetimes (average photon
# arrival times) calculated by LAS X software. The Fast FLIM lifetimes are
# corrected for the IRF position, which is extracted from metadata:

phase_lifetime, modulation_lifetime = phasor_to_apparent_lifetime(
    real, imag, frequency
)

fastflim_lifetime, _, _, attrs = lifetime_from_lif(fetch(filename))
fastflim_lifetime[numpy.isnan(mean)] = numpy.nan

frequency = attrs['frequency']
reference = attrs['flim_phasor_channels'][0]['AutomaticReferencePhase']
fastflim_lifetime -= math.radians(reference) / (2 * math.pi) / frequency * 1000

plot_histograms(
    phase_lifetime,
    modulation_lifetime,
    fastflim_lifetime,
    range=(0, 10),
    bins=100,
    alpha=0.6,
    xlabel='Lifetime (ns)',
    ylabel='Count',
    labels=[
        'Phase lifetime',
        'Modulation lifetime',
        'Fast FLIM lifetime',
    ],
    title='Lifetime histograms',
)

# %%
# The apparent single lifetimes from phase and modulation do not exactly match
# and the Fast FLIM lifetimes lie between them.
# Most likely there is more than one lifetime component in the sample.

# %%
# .. note::
#   Reading of FLIM/TCSPC histograms from LIF-FLIM files is not supported
#   yet because the storage scheme is undocumented or patent-pending.
#   However, TTTR records can be exported to PTU format using LAS X software.

# %%
# LIF hyperspectral
# .................
#
# The :py:func:`~phasorpy.io.signal_from_lif` function is used to read an
# image stack from the `Convallaria hyperspectral dataset
# <https://zenodo.org/records/14976703>`_ acquired at 29 emission wavelengths:

from phasorpy.io import signal_from_lif

filename = 'Convalaria_LambdaScan.lif'  # filename contains spelling error

signal = signal_from_lif(fetch(filename))

plot_signal_image(signal, vmin=0, xlabel='wavelength (nm)', title=filename)

# %%
# Emission wavelengths (in nm) are available in the coordinates of the
# channel axis:

print(signal.coords['C'].values.astype(int))

# %%
# Plot the first harmonic phasor coordinates after applying a median filter:

plot_phasor(
    *phasor_threshold(
        *phasor_filter_median(*phasor_from_signal(signal)), mean_min=1
    )[1:],
    allquadrants=True,
    title=filename,
)

# %%
# PicoQuant PTU
# -------------
#
# PicoQuant PTU files are written by PicoQuant SymPhoTime, Leica LAS X, and
# other software. The files contain time-correlated single-photon
# counting (TCSPC) measurement data and instrument parameters.
#
# PhasorPy supports reading TCSPC histograms from PTU files acquired in T3
# imaging mode via the `ptufile <https://github.com/cgohlke/ptufile/>`_
# library.
#
# The :py:func:`~phasorpy.io.signal_from_ptu` function is used to read
# the TCSPC histogram from a PTU file exported from the `FLIM testdata
# dataset <https://dx.doi.org/10.6084/m9.figshare.22336594.v1>`_.
# For phasor analysis, periods containing multiple photons must have all
# their photons discarded before exporting to PTU format. In the Leica
# LAS X software, select the "FLIM" tab, click on the "Phasor" button,
# and under "Specialist Settings" select the option "Standard (High Speed)".
# The first channel in the first frame is read from the PTU file:

from phasorpy.io import signal_from_ptu

filename = 'FLIM_testdata.lif.filtered.ptu'

signal = signal_from_ptu(fetch(filename), channel=0, frame=0)

plot_signal_image(signal, xlabel='delay time (ns)', title=filename)

# %%
# The returned ``signal`` is an `xarray.DataArray
# <https://docs.xarray.dev/en/stable/generated/xarray.DataArray.html>`_
# holding the TCSPC histogram as a NumPy array, and metadata as a
# dictionary in the ``attrs`` property.
# The metadata includes all PTU tags and the fundamental frequency, which
# is needed to interpret the phasor coordinates.
# The reference phase and modulation previously loaded from the LIF-FLIM file
# are again used to calibrate the phasor coordinates. The same intensity
# threshold is applied:

frequency = signal.attrs['frequency']
assert frequency == attrs['frequency']  # frequency matches LIF metadata

mean, real, imag = phasor_from_signal(signal)

real, imag = phasor_transform(
    real, imag, -math.radians(reference_phase), 1 / reference_modulation
)

mean, real, imag = phasor_threshold(mean, real, imag, mean_min=intensity_min)

plot_phasor(
    real,
    imag,
    frequency=frequency,
    cmin=10,
    title=f'{filename} ({frequency} MHz)',
)

# %%
# Compare the apparent single lifetimes calculated from the PTU file with the
# lifetimes previously read from the LIF-FLIM file:

plot_histograms(
    phasor_to_apparent_lifetime(real, imag, frequency)[0],
    phase_lifetime,
    range=(0, 10),
    bins=100,
    alpha=0.6,
    xlabel='Lifetime (ns)',
    ylabel='Count',
    labels=['Phase lifetime from PTU', 'Phase lifetime from LIF'],
    title='Lifetime histograms',
)

# %%
# Zeiss CZI
# ---------
#
# Carl Zeiss image files (CZI) are written by Zeiss ZEN software.
# They contain images and metadata from a variety of microscopy acquisition
# and analysis modes, including hyperspectral imaging.
#
# PhasorPy supports reading hyperspectral and RGB images from CZI files
# via the `czifile <https://github.com/cgohlke/czifile/>`_ library.
#
# The :py:func:`~phasorpy.io.signal_from_czi` function is used to read
# a hyperspectral image with 28 emission wavelengths from a CZI file:

from phasorpy.io import signal_from_czi

filename = 'test_file.zstd.czi'

signal = signal_from_czi(fetch(filename))

plot_signal_image(signal, xlabel='wavelength (nm)', title=filename)

# %%
# Emission wavelengths (in nm) are available in the coordinates of the
# channel axis ('C'):

print(signal.coords['C'].values.astype(int))

# %%
# Plot the first harmonic phasor coordinates after applying a median filter:

plot_phasor(
    *phasor_threshold(
        *phasor_filter_median(*phasor_from_signal(signal)), mean_min=1
    )[1:],
    allquadrants=True,
    title=filename,
)

# %%
# Zeiss LSM
# ---------
#
# Carl Zeiss LSM files, a predecessor of the CZI format, are written by
# Zeiss ZEN software. They contain images and metadata from laser-scanning
# microscopy.
#
# PhasorPy supports reading hyperspectral image data from Zeiss LSM files
# via the `tifffile <https://github.com/cgohlke/tifffile/>`_ library.
#
# The :py:func:`~phasorpy.io.signal_from_lsm` function is used to read
# a hyperspectral image with 30 emission wavelengths from an LSM file:

from phasorpy.io import signal_from_lsm

filename = 'paramecium.lsm'

signal = signal_from_lsm(fetch(filename))

plot_signal_image(signal, xlabel='wavelength (nm)', title=filename)

# %%
# Plot the first harmonic phasor coordinates after applying a median filter:

plot_phasor(
    *phasor_threshold(
        *phasor_filter_median(*phasor_from_signal(signal)), mean_min=1
    )[1:],
    allquadrants=True,
    title=filename,
)

# %%
# Becker & Hickl SDT
# ------------------
#
# SDT files are written by Becker & Hickl software.
# They may contain TCSPC histograms and metadata from laser-scanning
# microscopy.
#
# PhasorPy supports reading TCSPC histograms from SDT files via the
# `sdtfile <https://github.com/cgohlke/sdtfile/>`_ library.
#
# The :py:func:`~phasorpy.io.signal_from_sdt` function is used to read a
# TCSPC histogram from an SDT file:

from phasorpy.io import signal_from_sdt

filename = 'tcspc.sdt'

signal = signal_from_sdt(fetch(filename))

plot_signal_image(signal, xlabel='delay time (ns)', title=filename)

# %%
# Plot the uncalibrated phasor coordinates:

frequency = signal.attrs['frequency']

plot_phasor(
    *phasor_from_signal(signal)[1:],
    allquadrants=True,
    style='hist2d',
    title=f'{filename} ({frequency:.1f} MHz)',
)

# %%
# .. todo::
#   No accompanying IRF dataset is available to calibrate the phasor
#   coordinates.

# %%
# FLIMbox FBD
# -----------
#
# FLIMbox data files, FBD, are written by SimFCS and ISS software.
# They contain encoded cross-correlation phase histograms from digital
# frequency-domain measurements acquired with a FLIMbox device.
# Newer file versions also contain metadata.
#
# The FBD file format is undocumented and not standardized, and files are
# frequently found corrupted. Therefore, it is recommended to export FLIMbox
# files to another format from the software used to acquire the data.
#
# PhasorPy supports reading some FLIMbox FBD files via the
# `fbdfile <https://github.com/cgohlke/fbdfile/>`_ library.
#
# The :py:func:`~phasorpy.io.signal_from_fbd` function is used to read
# phase histograms from the
# `Convallaria FBD dataset <https://zenodo.org/records/14026720>`_, which was
# acquired at the second harmonic frequency. The dataset is a time series of
# two channels. Since the photon count is low and the second channel empty,
# only the first channel is read and the time-axis integrated.
# A corrected ``scanner_line_start`` parameter is specified to account for
# additional hardware trigger latency not present in the file metadata:

from phasorpy.io import signal_from_fbd

filename = 'Convallaria_$EI0S.fbd'

signal = signal_from_fbd(
    fetch(filename), frame=-1, channel=0, scanner_line_start=41
)

frequency = signal.attrs['frequency'] * signal.attrs['harmonic']

plot_signal_image(
    signal, xlabel='cross-correlation phase (rad)', title=filename
)

# %%
# The measurement of a solution of Rhodamine 110 with known lifetime of 4 ns
# is used as a calibration reference:

reference_filename = 'Calibration_Rhodamine110_$EI0S.fbd'

reference_signal = signal_from_fbd(
    fetch(reference_filename), frame=-1, channel=0, scanner_line_start=41
)
reference_lifetime = 4.0

plot_signal_image(
    reference_signal,
    xlabel='cross-correlation phase (rad)',
    title=reference_filename,
)

# %%
# Phasor coordinates are calculated from the signal and calibrated with
# the reference signal:

mean, real, imag = phasor_from_signal(signal)

real, imag = phasor_calibrate(
    real,
    imag,
    *phasor_from_signal(reference_signal),
    frequency,
    reference_lifetime,
)

plot_phasor(
    *phasor_threshold(
        *phasor_filter_median(mean, real, imag, repeat=3), mean_min=1
    )[1:],
    frequency=frequency,
    title=f'{filename} ({frequency} MHz)',
)

# %%
# FLIM LABS JSON
# --------------
#
# FLIM LABS JSON files are written by FLIM Studio software.
# They contain multi-channel TCSPC histogram images, optional calibrated
# multi-harmonic phasor coordinates, and metadata from digital frequency-domain
# measurements.
#
# The :py:func:`~phasorpy.io.signal_from_flimlabs_json` function is used to
# read a TCSPC histogram from the `Convallaria FLIM LABS dataset
# <https://zenodo.org/records/15007900>`_, which contains a single channel:

from phasorpy.io import signal_from_flimlabs_json

channel = 0
filename = 'Convallaria_m2_1740751781_phasor_ch1.json'

signal = signal_from_flimlabs_json(fetch(filename), channel=channel)

plot_signal_image(signal, xlabel='delay time (ns)', title=filename)

# %%
# Phasor coordinates are calculated from the TCSPC histogram at three
# harmonics and calibrated using the metadata in ``signal.attrs`` and the
# TCSPC histogram from the measurement of a Fluorescein solution of known
# lifetime:

harmonic = [1, 2, 3]
frequency = signal.attrs['frequency']
reference_lifetime = signal.attrs['flimlabs_header']['tau_ns']

mean, real, imag = phasor_from_signal(signal, harmonic=harmonic)

reference_mean, reference_real, reference_imag = phasor_from_signal(
    signal_from_flimlabs_json(
        fetch('Fluorescein_Calibration_m2_1740751189_imaging.json'),
        channel=channel,
    ),
    harmonic=harmonic,
)

real, imag = phasor_calibrate(
    real,
    imag,
    reference_mean,
    reference_real,
    reference_imag,
    frequency,
    reference_lifetime,
    harmonic=harmonic,
)

# %%
# Plot the second harmonic phasor coordinates:

plot_phasor(
    real[1],  # index 1 corresponds to second harmonic
    imag[1],
    frequency=frequency * 2,
    cmin=10,
    title=f'{filename} ({frequency * 2:.1f} MHz)',
)

# %%
# Newer versions of the FLIM LABS JSON files may also contain calibrated
# phasor coordinates, possibly at multiple harmonics, which can be read
# using the :py:func:`~phasorpy.io.phasor_from_flimlabs_json` function.
# These calibrated phasors match those previously computed from the TCSPC
# histograms and metadata:

from phasorpy.io import phasor_from_flimlabs_json

mean_fromfile, real_fromfile, imag_fromfile, attrs = phasor_from_flimlabs_json(
    fetch(filename), channel=channel, harmonic='all'
)

assert attrs['harmonic'] == [1, 2, 3]
assert numpy.allclose(mean_fromfile, mean, atol=1e-3, equal_nan=True)
assert numpy.allclose(real_fromfile, real, atol=1e-3, equal_nan=True)
assert numpy.allclose(imag_fromfile, imag, atol=1e-3, equal_nan=True)

# %%
# The reference phase, modulation, and lifetime used to calibrate the phasor
# coordinates may also be found in an accompanying JSON file:

import json

with open(
    fetch('Fluorescein_Calibration_m2_1740751189_imaging_calibration.json'),
    'rb',
) as fh:
    attrs = json.load(fh)

calibration = numpy.asarray(attrs['calibrations'][channel])
reference_phase = -calibration[:, 0, None, None]
reference_modulation = 1 / calibration[:, 1, None, None]
reference_lifetime = attrs['tau_ns']
frequency = attrs['frequency_mhz']

# %%
# ISS IFLI
# --------
#
# IFLI files are written by ISS VistaVision software. They contain calibrated
# phasor coordinates from analog or digital frequency-domain lifetime
# measurements.
# IFLI datasets can be up to 9-dimensional in the order of mean/real/imag,
# frequency, position, emission wavelength, time, channel, Z, Y, and X.
#
# PhasorPy supports reading ISS IFLI files via the
# `lfdfiles <https://github.com/cgohlke/lfdfiles/>`_ library.
#
# The :py:func:`~phasorpy.io.phasor_from_ifli` function is used to read
# calibrated phasor coordinates from a measurement of liver from mice fed
# a Western diet. Select the second channel and first three harmonics:

from phasorpy.io import phasor_from_ifli

filename = 'NADHandSHG.ifli'

mean, real, imag, attrs = phasor_from_ifli(
    fetch(filename),
    harmonic='all',
    channel=1,  # NADH channel
)

plot_phasor_image(mean, real, imag, title=filename)

# %%
# The first channel in the file contains an SHG image with phasor coordinates
# about zero:

assert (
    phasor_from_ifli(
        fetch(filename), harmonic='all', channel=0  # SHG channel
    )[1].mean()
    < 1e-2
)

# %%
# The ``attrs`` dictionary holds metadata including the fundamental frequency,
# the harmonics in the phasor coordinates, and the reference phasor coordinates
# used for calibration:

frequency = attrs['frequency']
harmonic = attrs['harmonic']
reference_phasor = attrs['ifli_header']['RefDCPhasor']
reference_lifetime = attrs['ifli_header']['RefLifetime']

# %%
# Plot the first harmonic phasor coordinates after applying a median filter:

plot_phasor(
    *phasor_filter_median(mean, real[0], imag[0], repeat=2)[1:],
    frequency=frequency,
    cmin=10,
    title=f'{filename} ({frequency:.2f} MHz)',
)

# %%
# Three main lifetime components are expected in the sample: free
# NADH (~0.4 ns), bound NADH (3.4 ns), and a long lifetime species (~8 ns).
# It appears the calibration is off in this sample.

# %%
# SimFCS REF and R64
# ------------------
#
# Referenced files, REF and R64, are written by the SimFCS software and
# supported in several other software packages.
# The files most commonly contain a square average intensity image and
# the calibrated phasor coordinates of the first two harmonics.
#
# PhasorPy supports reading and writing SimFCS Referenced files via the
# `lfdfiles <https://github.com/cgohlke/lfdfiles/>`_ library.
#
# The :py:func:`~phasorpy.io.phasor_from_simfcs_referenced` function is used
# to read calibrated phasor coordinates from a REF file
# from the `LFD workshop dataset <https://zenodo.org/records/8411056>`_:

from phasorpy.io import phasor_from_simfcs_referenced

filename = 'capillaries1001.ref'

mean, real, imag, attrs = phasor_from_simfcs_referenced(
    fetch(filename), harmonic='all'
)

plot_phasor_image(mean, real, imag, title=filename)

# %%
# Plot the first harmonic phasor coordinates after applying a median filter.
# Since SimFCS Referenced files do not contain metadata, the frequency and
# harmonics must be known by the user:

frequency = 80.0  # MHz
harmonic = [1, 2]

plot_phasor(
    *phasor_threshold(
        *phasor_filter_median(mean, real[0], imag[0]),
        mean_min=25,
        real_min=1e-3,
    )[1:],
    frequency=frequency,
    cmin=2,
    title=f'{filename} ({frequency:.2f} MHz)',
)

# %%
# The :py:func:`~phasorpy.io.phasor_to_simfcs_referenced` function is used
# to write calibrated phasor coordinates to R64 files in a temporary directory.
# Images with more than two dimensions or larger than square size are
# chunked to square images and saved to separate files.
# Images or chunks with less than two dimensions or smaller than square size
# are padded with NaN values:

from phasorpy.io import phasor_to_simfcs_referenced

with TemporaryDirectory() as tmpdir:

    filename = os.path.join(tmpdir, 'capillaries1001.r64')
    phasor_to_simfcs_referenced(filename, mean, real, imag, size=160)

    # print file names
    filenames = sorted(os.listdir(tmpdir))
    for filename in filenames:
        print(filename)

    # verify the first harmonic phasor coordinates in the last file
    assert numpy.allclose(
        phasor_from_simfcs_referenced(os.path.join(tmpdir, filenames[-1]))[1],
        numpy.pad(real[0, 160:, 160:], (0, 64), constant_values=numpy.nan),
        atol=1e-3,
        equal_nan=True,
    )

# %%
# PhasorPy OME-TIFF
# -----------------
#
# PhasorPy can store phasor coordinates and selected metadata in
# `OME-TIFF <https://ome-model.readthedocs.io/en/stable/ome-tiff/>`_
# formatted files, which are compatible with Bio-Formats, Fiji, and other
# software. The implementation is based on the
# `tifffile <https://github.com/cgohlke/tifffile/>`_ library.
#
# Compared to the SimFCS R64 format, OME-TIFF offers several advantages.
# It can store higher-dimensional, higher-precision images of any size,
# any number of harmonics, and selected metadata.
#
# PhasorPy OME-TIFF files are intended for temporarily exchanging phasor
# coordinates with other software, not as a long-term storage solution.
# Always preserve original data files in their native formats.
#
# The :py:func:`~phasorpy.io.phasor_to_ometiff` and
# :py:func:`~phasorpy.io.phasor_from_ometiff` functions are used to write and
# read back calibrated phasor coordinates to/from PhasorPy OME-TIFF files:

from phasorpy.io import phasor_from_ometiff, phasor_to_ometiff

with TemporaryDirectory() as tmpdir:

    filename = os.path.join(tmpdir, 'capillaries1001.ome.tif')

    phasor_to_ometiff(
        filename,
        mean,
        real,
        imag,
        frequency=frequency,
        dims='YX',
        description='Written by PhasorPy',
    )

    mean1, real1, imag1, attrs = phasor_from_ometiff(filename, harmonic='all')
    assert numpy.allclose(mean, mean1, atol=1e-3, equal_nan=True)
    assert attrs['frequency'] == frequency
    assert attrs['harmonic'] == [1, 2]
    assert attrs['description'] == 'Written by PhasorPy'

# %%
# Other supported formats
# -----------------------
#
# PhasorPy supports reading time-resolved signals from additional file formats:
# :py:func:`~phasorpy.io.signal_from_pqbin` (PicoQuant BIN),
# :py:func:`~phasorpy.io.signal_from_tdflim` (ISS TDFLIM),
# :py:func:`~phasorpy.io.signal_from_imspector_tiff` (ImSpector FLIM TIFF),
# :py:func:`~phasorpy.io.signal_from_brighteyes_mcs` (BrightEyes-MCS HDF5),
# and :py:func:`~phasorpy.io.signal_from_flif` (FlimFast FLIF).
#
# SimFCS signals can be read from B64, Z64, BHZ, and B&H files using
# :py:func:`~phasorpy.io.signal_from_b64`,
# :py:func:`~phasorpy.io.signal_from_z64`,
# :py:func:`~phasorpy.io.signal_from_bhz`, and
# :py:func:`~phasorpy.io.signal_from_bh`.

# %%
# Alternative import methods
# --------------------------
#
# While PhasorPy provides many functions to read phasor-related data and
# metadata from file formats commonly used in the field, it is by no means
# required to use those functions.
# Instead, any other means that yields image stacks in NumPy array-compatible
# form can be used (for example) for advanced use cases, or when a file
# format is not supported by PhasorPy.
#
# For example, most imaging software can export image data to generic
# TIFF files.
# The `tifffile <https://github.com/cgohlke/tifffile/>`_ library is used to
# read a TCSPC histogram exported to a TIFF file by ImSpector software:

from tifffile import imread

filename = 'Embryo.tif'

image_stack = imread(fetch(filename))

# %%
# Since the image stack array contains no domain-specific metadata, the
# fundamental frequency and the axis over which to calculate phasor
# coordinates must be known. In this case, the TCSPC histogram bins are in
# the first array dimension:

plot_signal_image(image_stack, axis=0, xlabel='index', title=filename)

mean, real, imag = phasor_from_signal(image_stack, axis=0)

# %%
# Plot the uncalibrated phasor coordinates:

plot_phasor(real, imag, frequency=80.0, allquadrants=True, title=filename)

# sphinx_gallery_start_ignore
# sphinx_gallery_thumbnail_number = 13
# mypy: allow-untyped-defs, allow-untyped-calls
# mypy: disable-error-code="arg-type"
# sphinx_gallery_end_ignore
